#include "Engine.hpp"

#ifdef TRACY_ENABLE
    #include <tracy/Tracy.hpp>
    #include <iostream>
#endif

#ifdef _MSVC
#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:mainCRTStartup")
#endif

bool Engine::init() {
    if (!renderer.init()) {
        return false;
    }
    
    if (!audio.init()) {
        renderer.shutdown();
        return false;
    }
    
    assets.set_base_path("../../img/");
    assets.load_avatar_state(AvatarState::IDLE, IDLE_MAX_FRAMES, "idle");
    assets.load_avatar_state(AvatarState::TALKING, TALK_MAX_FRAMES, "talk");
    assets.load_avatar_state(AvatarState::SCREAMING, SCREAM_MAX_FRAMES, "scream");

    renderer.set_max_frames(IDLE_MAX_FRAMES, TALK_MAX_FRAMES, SCREAM_MAX_FRAMES);

    isRunning = true;
    return true;
}

void Engine::process_input() {
    if (renderer.should_close()) {
        isRunning = false;
    }

    if (input.is_interface_toggled()) {
        renderer.toggle_ui_visibility();
    }
}

void Engine::update() {
    current_volume = Utils::smooth_volume(current_volume, audio.rms);
    
    sensitivity = renderer.get_sensitivity();
    float final_vol = current_volume * sensitivity;

    if (final_vol < 0.2f) {
        current_state = AvatarState::IDLE;
    } else if (final_vol < 0.7f) {
        current_state = AvatarState::TALKING;
    } else {
        current_state = AvatarState::SCREAMING;
    }
    
    renderer.set_avatar_state(current_state);
}

void Engine::render() {
    renderer.update(assets, current_volume);
}

void Engine::run() {
    while (isRunning) {
        {
            #ifdef TRACY_ENABLE
                ZoneScopedN("Process input");
            #endif
            process_input();
        }

        {
            #ifdef TRACY_ENABLE
                ZoneScopedN("Update");
            #endif
            update();
        }

        {
            #ifdef TRACY_ENABLE
                ZoneScopedN("Render");
            #endif
            render();
        }

        #ifdef TRACY_ENABLE
            FrameMark;
        #endif
    }
}

void Engine::shutdown() {
    audio.shutdown();
    assets.clear_all();
    renderer.shutdown();
}
